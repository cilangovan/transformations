/*************************************************************************************** 
 * Copyright (C) 2007 Sven Boden (svenboden@illunus.com).  All rights reserved. 
 * This software was developed by Sven Boden and is provided under the terms 
 * of the GNU Lesser General Public License, Version 2.1. You may not use 
 * this file except in compliance with the license. A copy of the license, 
 * is included with the binaries and source code. The Original Code is Sven Boden.  
 * The Initial Developer is Sven Boden.
 *
 * Software distributed under the GNU Lesser Public License is distributed on an 
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. 
 * Please refer to the license for the specific language governing your rights 
 * and limitations.
 ***************************************************************************************/

package com.illunus.di.trans.steps.dategenerator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.pentaho.di.core.CheckResult;
import org.pentaho.di.core.CheckResultInterface;
import org.pentaho.di.core.Const;
import org.pentaho.di.core.Counter;
import org.pentaho.di.core.annotations.Step;
import org.pentaho.di.core.database.DatabaseMeta;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.exception.KettleStepException;
import org.pentaho.di.core.exception.KettleXMLException;
import org.pentaho.di.core.row.RowMetaInterface;
import org.pentaho.di.core.row.ValueMeta;
import org.pentaho.di.core.row.ValueMetaInterface;
import org.pentaho.di.core.util.StringUtil;
import org.pentaho.di.core.variables.VariableSpace;
import org.pentaho.di.core.xml.XMLHandler;
import org.pentaho.di.repository.Repository;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.BaseStepMeta;
import org.pentaho.di.trans.step.StepCategory;
import org.pentaho.di.trans.step.StepDataInterface;
import org.pentaho.di.trans.step.StepInterface;
import org.pentaho.di.trans.step.StepMeta;
import org.pentaho.di.trans.step.StepMetaInterface;
import org.w3c.dom.Node;

@Step(name = "DateGenerator", image = "com/illunus/di/trans/steps/dategenerator/DGN.png", tooltip = "DateGeneratorMeta.TypeTooltipDesc.DateGenerator", description = "DateGeneratorMeta.TypeLongDesc.DateGenerator", category = StepCategory.CATEGORY_INPUT)
public class DateGeneratorMeta extends BaseStepMeta implements
		StepMetaInterface {
	/**
	 * Name of the new field to insert.
	 */
	private String fieldName;

	/**
	 * Format of the begin and end date.
	 */
	private String dateFormat;

	/**
	 * Begin date (including this one).
	 */
	private String beginDate;

	/**
	 * End date (excluding this one).
	 */
	private String endDate;

	/**
	 * Discard rows after the end date when the step receives input.
	 */
	private boolean discardRowsAfterEnd;

	// private SimpleDateFormat dateFormat;

	public DateGeneratorMeta() {
		super();
	}

	public void loadXML(Node stepnode, List<DatabaseMeta> databases,
			Map<String, Counter> counters) throws KettleXMLException {
		readData(stepnode);
	}

	public Object clone() {
		DateGeneratorMeta retval = (DateGeneratorMeta) super.clone();

		return retval;
	}

	private void readData(Node stepnode) throws KettleXMLException {
		try {
			fieldName = XMLHandler.getTagValue(stepnode, "field_name");
			dateFormat = XMLHandler.getTagValue(stepnode, "date_format");
			beginDate = XMLHandler.getTagValue(stepnode, "begin_date");
			endDate = XMLHandler.getTagValue(stepnode, "end_date");
			discardRowsAfterEnd = "Y".equalsIgnoreCase(XMLHandler.getTagValue(
					stepnode, "discard_rows"));
		} catch (Exception e) {
			throw new KettleXMLException("Unable to load step info from XML", e);
		}
	}

	public void setDefault() {
		fieldName = "date";
		dateFormat = "yyyyMMdd";
		beginDate = "19710101";
		endDate = "20300101";
		discardRowsAfterEnd = false;
	}

	public void getFields(RowMetaInterface row, String origin,
			RowMetaInterface[] info, StepMeta nextStep, VariableSpace space)
			throws KettleStepException {
		//
		// We fill in a a default in the field name is not yet defined.
		// This doesn't matter much as the step will abort on it.
		//
		String name = Const.isEmpty(getFieldName()) ? "date" : getFieldName();
		ValueMetaInterface v = new ValueMeta(name, ValueMetaInterface.TYPE_DATE);
		v.setOrigin(origin);

		if (!Const.isEmpty(getDateFormat())) {
			v.setConversionMask(getDateFormat());
		}
		row.addValueMeta(v);
	}

	public String getXML() {
		StringBuffer retval = new StringBuffer(300);

		retval.append("    ").append(
				XMLHandler.addTagValue("field_name", fieldName)).append(
				Const.CR);
		retval.append("    ").append(
				XMLHandler.addTagValue("date_format", dateFormat)).append(
				Const.CR);
		retval.append("    ").append(
				XMLHandler.addTagValue("begin_date", beginDate)).append(
				Const.CR);
		retval.append("    ").append(
				XMLHandler.addTagValue("end_date", endDate)).append(Const.CR);
		retval.append("    ").append(
				XMLHandler.addTagValue("discard_rows", discardRowsAfterEnd))
				.append(Const.CR);

		return retval.toString();
	}

	public void readRep(Repository rep, long id_step,
			List<DatabaseMeta> databases, Map<String, Counter> counters)
			throws KettleException {
		try {
			fieldName = rep.getStepAttributeString(id_step, "field_name");
			dateFormat = rep.getStepAttributeString(id_step, "date_format");
			beginDate = rep.getStepAttributeString(id_step, "begin_date");
			endDate = rep.getStepAttributeString(id_step, "end_date");
			discardRowsAfterEnd = rep.getStepAttributeBoolean(id_step,
					"discard_rows");
		} catch (Exception e) {
			throw new KettleException(
					"Unexpected error reading step information from the repository",
					e);
		}
	}

	public void saveRep(Repository rep, long id_transformation, long id_step)
			throws KettleException {
		try {
			rep.saveStepAttribute(id_transformation, id_step, "field_name",
					fieldName);
			rep.saveStepAttribute(id_transformation, id_step, "date_format",
					dateFormat);
			rep.saveStepAttribute(id_transformation, id_step, "begin_date",
					beginDate);
			rep.saveStepAttribute(id_transformation, id_step, "end_date",
					endDate);
			rep.saveStepAttribute(id_transformation, id_step, "discard_rows",
					discardRowsAfterEnd);
		} catch (Exception e) {
			throw new KettleException(
					"Unable to save step information to the repository for id_step="
							+ id_step, e);
		}
	}

	public void check(List<CheckResultInterface> remarks, TransMeta transMeta,
			StepMeta stepMeta, RowMetaInterface prev, String input[],
			String output[], RowMetaInterface info) {
		CheckResult cr;
		if (prev == null) {
			cr = new CheckResult(
					CheckResultInterface.TYPE_RESULT_OK,
					Messages
							.getString("DateGeneratorMeta.CheckResult.NoInputStreamOk"),
					stepMeta);
			remarks.add(cr);
		}

		// See if we have input streams leading to this step!
		if (input.length <= 0) {
			cr = new CheckResult(CheckResultInterface.TYPE_RESULT_OK, Messages
					.getString("DateGeneratorMeta.CheckResult.NoInputOk"),
					stepMeta);
			remarks.add(cr);

			if (isDiscardRowsAfterEnd()) {
				// It's only a warning as we ignore the discard rows after end.
				cr = new CheckResult(
						CheckResultInterface.TYPE_RESULT_WARNING,
						Messages
								.getString("DateGeneratorMeta.CheckResult.DiscardRowsNoInput"),
						stepMeta);
				remarks.add(cr);
			}
		}

		SimpleDateFormat sdf = null;

		List<String> varList = new ArrayList<String>();
		StringUtil.getUsedVariables(dateFormat, varList, true);
		if (varList.isEmpty()) {
			// If we're not using variables we can already check the dateformat
			try {
				sdf = new SimpleDateFormat(dateFormat);
			} catch (IllegalArgumentException ex) {
				cr = new CheckResult(
						CheckResultInterface.TYPE_RESULT_ERROR,
						Messages
								.getString(
										"DateGeneratorMeta.CheckResult.DateFormatNotOk",
										ex.getMessage()), stepMeta);
				remarks.add(cr);
			}

			if (sdf != null) {
				cr = new CheckResult(
						CheckResultInterface.TYPE_RESULT_OK,
						Messages
								.getString("DateGeneratorMeta.CheckResult.DateFormatOk"),
						stepMeta);
				remarks.add(cr);
			}
		}

		varList.clear();
		StringUtil.getUsedVariables(beginDate, varList, true);
		if (varList.isEmpty()) {
			Date bDate = null;

			try {
				bDate = sdf.parse(beginDate);
			} catch (ParseException ex) {
				cr = new CheckResult(CheckResultInterface.TYPE_RESULT_ERROR,
						Messages.getString(
								"DateGeneratorMeta.CheckResult.BeginDateNotOk",
								ex.getMessage()), stepMeta);
				remarks.add(cr);
			}
			if (bDate != null) {
				cr = new CheckResult(
						CheckResultInterface.TYPE_RESULT_OK,
						Messages
								.getString("DateGeneratorMeta.CheckResult.BeginDateOk"),
						stepMeta);
				remarks.add(cr);
			}
		}

		varList.clear();
		StringUtil.getUsedVariables(endDate, varList, true);
		if (varList.isEmpty()) {
			Date eDate = null;

			try {
				eDate = sdf.parse(endDate);
			} catch (ParseException ex) {
				cr = new CheckResult(CheckResultInterface.TYPE_RESULT_ERROR,
						Messages.getString(
								"DateGeneratorMeta.CheckResult.EndDateNotOk",
								ex.getMessage()), stepMeta);
				remarks.add(cr);
			}
			if (eDate != null) {
				cr = new CheckResult(
						CheckResultInterface.TYPE_RESULT_OK,
						Messages
								.getString("DateGeneratorMeta.CheckResult.EndDateOk"),
						stepMeta);
				remarks.add(cr);
			}
		}
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return Returns the date format.
	 */
	public String getDateFormat() {
		return dateFormat;
	}

	/**
	 * @param dateFirnat
	 *            The date format to set.
	 */
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}

	public String getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public boolean isDiscardRowsAfterEnd() {
		return discardRowsAfterEnd;
	}

	public void setDiscardRowsAfterEnd(boolean discardRowsAfterEnd) {
		this.discardRowsAfterEnd = discardRowsAfterEnd;
	}

	public StepInterface getStep(StepMeta stepMeta,
			StepDataInterface stepDataInterface, int cnr, TransMeta transMeta,
			Trans trans) {
		return new DateGenerator(stepMeta, stepDataInterface, cnr, transMeta,
				trans);
	}

	public StepDataInterface getStepData() {
		return new DateGeneratorData();
	}

	public String getDialogClassName() {
		return "com.illunus.di.ui.trans.steps.dategenerator.DateGeneratorDialog";
	}
}