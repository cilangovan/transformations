/*************************************************************************************** 
 * Copyright (C) 2007 Sven Boden (svenboden@illunus.com).  All rights reserved. 
 * This software was developed by Sven Boden and is provided under the terms 
 * of the GNU Lesser General Public License, Version 2.1. You may not use 
 * this file except in compliance with the license. A copy of the license, 
 * is included with the binaries and source code. The Original Code is Sven Boden.  
 * The Initial Developer is Sven Boden.
 *
 * Software distributed under the GNU Lesser Public License is distributed on an 
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. 
 * Please refer to the license for the specific language governing your rights 
 * and limitations.
 ***************************************************************************************/

package com.illunus.di.trans.steps.dategenerator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.pentaho.di.core.Const;
import org.pentaho.di.core.RowSet;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.row.RowDataUtil;
import org.pentaho.di.core.row.RowMeta;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.BaseStep;
import org.pentaho.di.trans.step.StepDataInterface;
import org.pentaho.di.trans.step.StepInterface;
import org.pentaho.di.trans.step.StepMeta;
import org.pentaho.di.trans.step.StepMetaInterface;

/**
 * Generates a number of successive dates.
 * 
 * @author Sven Boden
 * @since 25Nov20073
 */
public class DateGenerator extends BaseStep implements StepInterface {
	private DateGeneratorMeta meta;

	private DateGeneratorData data;

	public DateGenerator(StepMeta stepMeta,
			StepDataInterface stepDataInterface, int copyNr,
			TransMeta transMeta, Trans trans) {
		super(stepMeta, stepDataInterface, copyNr, transMeta, trans);

		meta = (DateGeneratorMeta) getStepMeta().getStepMetaInterface();
		data = (DateGeneratorData) stepDataInterface;
	}

	public synchronized boolean processRow(StepMetaInterface smi,
			StepDataInterface sdi) throws KettleException {
		meta = (DateGeneratorMeta) smi;
		data = (DateGeneratorData) sdi;

		boolean retval = true;
		boolean skip = false;

		Object[] r = null;

		if (first == false || data.readFromInput == true) {
			// Even if we don't read from the input we need to call getRow()
			// to get the input row meta data to be setup.
			r = getRow();
		}

		if (first) {
			first = false;

			if (getInputRowMeta() != null) {
				// We get input from another step
				data.outputRowMeta = getInputRowMeta().clone();
				data.fieldNr = getInputRowMeta().size();
			} else {
				// We make our own data
				data.outputRowMeta = new RowMeta();
				data.fieldNr = 0;
			}
			meta.getFields(data.outputRowMeta, getStepname(), null, null, this);
		}

		if (!data.readFromInput) {
			if (data.nextDate.before(data.endDate)) {
				// still end date not reached
				Object[] rowData = RowDataUtil.allocateRowData(1);

				rowData[data.fieldNr] = data.nextDate.clone();
				data.cal.setTime(data.nextDate);
				data.cal.add(Calendar.DAY_OF_MONTH, 1);
				data.nextDate = data.cal.getTime();

				putRow(data.outputRowMeta, rowData);
				data.rowsWritten++;

				if (log.isRowLevel()) {
					log.logRowlevel(toString(), Messages.getString(
							"DateGenerator.Log.Wrote.Row", Long
									.toString(data.rowsWritten),
							data.outputRowMeta.getString(r)));
				}

				if (checkFeedback(getLinesRead()))
					logBasic(Messages.getString("DateGenerator.Log.LineNr",
							Long.toString(data.rowsWritten)));
			} else {
				// We generate data and our current date is
				// now beyond the end date... we're done
				setOutputDone();
				return false;
			}
		} else {
			// Reading from input and adding data
			if (r == null) {
				// End of the input reached, we also stop.
				setOutputDone();
				return false;
			}

			Date newDate = null;

			if (data.endDate != null) {
				// endDate == null means that there's no end date
				if (data.nextDate.before(data.endDate)) {
					newDate = (Date) data.nextDate.clone();
				} else {
					newDate = null;
					if (meta.isDiscardRowsAfterEnd()) {
						skip = true;
						Object[] tempRow = getRow();
						while (tempRow != null && !isStopped())
							tempRow = getRow();
					}
				}
			} else {
				// no end date
				newDate = (Date) data.nextDate.clone();
			}

			if (!skip) {
				Object[] rowData = RowDataUtil.createResizedCopy(r,
						r.length + 1);
				rowData[data.fieldNr] = newDate;
				data.cal.setTime(data.nextDate);
				data.cal.add(Calendar.DAY_OF_MONTH, 1);
				data.nextDate = data.cal.getTime();

				putRow(data.outputRowMeta, rowData);
				data.rowsWritten++;

				if (log.isRowLevel()) {
					log.logRowlevel(toString(), Messages.getString(
							"DateGenerator.Log.Wrote.Row", Long
									.toString(data.rowsWritten),
							data.outputRowMeta.getString(r)));
				}

				if (checkFeedback(getLinesRead()))
					logBasic(Messages.getString("DateGenerator.Log.LineNr",
							Long.toString(data.rowsWritten)));
			}
		}

		return retval;
	}

	public boolean init(StepMetaInterface smi, StepDataInterface sdi) {
		meta = (DateGeneratorMeta) smi;
		data = (DateGeneratorData) sdi;

		if (super.init(smi, sdi)) {

			// Determine whether we read from an input hop or whether we
			// generate as the Row Generator.
			List<RowSet> hops = getInputRowSets();
			if (hops.size() == 0)
				data.readFromInput = false;
			else
				data.readFromInput = true;

			data.cal = Calendar.getInstance();
			// Calculate begin and end date
			try {
				data.sdf = new SimpleDateFormat(environmentSubstitute(meta
						.getDateFormat()));
			} catch (IllegalArgumentException ex) {
				logError(Messages
						.getString(
								"DateGeneratorMeta.Exception.DateFormatWrong", environmentSubstitute(meta.getDateFormat()))); //$NON-NLS-1$ 
				logError(Const.getStackTracker(ex));
				return false;
			}

			try {
				data.beginDate = data.sdf.parse(environmentSubstitute(meta
						.getBeginDate()));
			} catch (ParseException ex) {
				logError(Messages
						.getString(
								"DateGeneratorMeta.Exception.BeginDateFormatError", environmentSubstitute(meta.getBeginDate()), environmentSubstitute(meta.getDateFormat()))); //$NON-NLS-1$ 
				logError(Const.getStackTracker(ex));
				return false;
			}

			String endDate = environmentSubstitute(meta.getEndDate());
			if (!Const.isEmpty(endDate)) {
				try {
					data.endDate = data.sdf.parse(environmentSubstitute(meta
							.getEndDate()));
				} catch (ParseException ex) {
					logError(Messages
							.getString(
									"DateGeneratorMeta.Exception.EndDateFormatError", environmentSubstitute(meta.getEndDate()), environmentSubstitute(meta.getDateFormat()))); //$NON-NLS-1$ 
					logError(Const.getStackTracker(ex));
					return false;
				}
			} else {
				if (data.readFromInput == true) {
					// no defined end date.
					data.endDate = null;
				} else {
					// If we don't read from the input we need to have an
					// enddate
					logError(Messages
							.getString("DateGeneratorMeta.Exception.EndDateNotDefined")); //$NON-NLS-1$ 
					return false;
				}
			}

			data.nextDate = data.beginDate;

			return true;
		}
		return false;
	}

	//
	// Run is were the action happens!
	public void run()
	{
    	BaseStep.runStepThread(this, meta, data);
	}
}