/*************************************************************************************** 
 * Copyright (C) 2007 Sven Boden (svenboden@illunus.com).  All rights reserved. 
 * This software was developed by Sven Boden and is provided under the terms 
 * of the GNU Lesser General Public License, Version 2.1. You may not use 
 * this file except in compliance with the license. A copy of the license, 
 * is included with the binaries and source code. The Original Code is Sven Boden.  
 * The Initial Developer is Sven Boden.
 *
 * Software distributed under the GNU Lesser Public License is distributed on an 
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. 
 * Please refer to the license for the specific language governing your rights 
 * and limitations.
 ***************************************************************************************/

package com.illunus.di.trans.steps.dategenerator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import org.pentaho.di.core.RowMetaAndData;
import org.pentaho.di.core.exception.KettleValueException;
import org.pentaho.di.core.row.RowMeta;
import org.pentaho.di.core.row.RowMetaInterface;
import org.pentaho.di.core.row.ValueMeta;
import org.pentaho.di.core.row.ValueMetaInterface;
import org.pentaho.di.core.util.EnvUtil;
import org.pentaho.di.trans.RowProducer;
import org.pentaho.di.trans.StepLoader;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransHopMeta;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.step.StepInterface;
import org.pentaho.di.trans.step.StepMeta;
import org.pentaho.di.trans.step.StepMetaInterface;
import org.pentaho.di.trans.steps.dummytrans.DummyTransMeta;
import org.pentaho.di.trans.steps.injector.InjectorMeta;

import com.illunus.di.trans.RowStepCollector;

/**
 * Test class for the DateGenerator step.
 * 
 * @author Sven Boden
 */
public class DateGeneratorTest extends TestCase {

	/**
	 * Return empty meta-data.
	 */
	public RowMetaInterface createRowMetaInterface1() {
		RowMetaInterface rm = new RowMeta();

		return rm;
	}

	public RowMetaInterface createResultRowMetaInterface1() {
		RowMetaInterface rm = new RowMeta();

		ValueMetaInterface valuesMeta[] = { new ValueMeta("date",
				ValueMeta.TYPE_DATE) };

		for (int i = 0; i < valuesMeta.length; i++) {
			rm.addValueMeta(valuesMeta[i]);
		}

		return rm;
	}

	public List<RowMetaAndData> createData1() {
		List<RowMetaAndData> list = new ArrayList<RowMetaAndData>();

		RowMetaInterface rm = createRowMetaInterface1();

		Object[] r1 = new Object[] {};
		Object[] r2 = new Object[] {};
		Object[] r3 = new Object[] {};
		Object[] r4 = new Object[] {};
		Object[] r5 = new Object[] {};

		list.add(new RowMetaAndData(rm, r1));
		list.add(new RowMetaAndData(rm, r2));
		list.add(new RowMetaAndData(rm, r3));
		list.add(new RowMetaAndData(rm, r4));
		list.add(new RowMetaAndData(rm, r5));

		return list;
	}

	/**
	 * Create result data for test case 1.
	 */
	public List<RowMetaAndData> createResultData1() {
		List<RowMetaAndData> list = new ArrayList<RowMetaAndData>();

		RowMetaInterface rm = createResultRowMetaInterface1();

		SimpleDateFormat sdf = null;
		try {
			sdf = new SimpleDateFormat("yyyyMMdd");
		} catch (IllegalArgumentException ex) {
			fail("Creating of result data failed in SimpleDateFormat: "
					+ ex.getMessage());
		}

		try {

			Object[] r1 = new Object[] { sdf.parse("20071225") };
			Object[] r2 = new Object[] { sdf.parse("20071226") };
			Object[] r3 = new Object[] { sdf.parse("20071227") };
			Object[] r4 = new Object[] { sdf.parse("20071228") };
			Object[] r5 = new Object[] { sdf.parse("20071229") };

			list.add(new RowMetaAndData(rm, r1));
			list.add(new RowMetaAndData(rm, r2));
			list.add(new RowMetaAndData(rm, r3));
			list.add(new RowMetaAndData(rm, r4));
			list.add(new RowMetaAndData(rm, r5));

		} catch (ParseException ex) {
			fail("Creating of result data failed in object creation: "
					+ ex.getMessage());
		}

		return list;
	}

	public RowMetaInterface createRowMetaInterface2() {
		RowMetaInterface rm = new RowMeta();

		ValueMetaInterface valuesMeta[] = { new ValueMeta("intfield",
				ValueMeta.TYPE_INTEGER) };

		for (int i = 0; i < valuesMeta.length; i++) {
			rm.addValueMeta(valuesMeta[i]);
		}

		return rm;
	}

	public RowMetaInterface createResultRowMetaInterface2() {
		RowMetaInterface rm = new RowMeta();

		ValueMetaInterface valuesMeta[] = {
				new ValueMeta("intfield", ValueMeta.TYPE_INTEGER),
				new ValueMeta("date", ValueMeta.TYPE_DATE) };

		for (int i = 0; i < valuesMeta.length; i++) {
			rm.addValueMeta(valuesMeta[i]);
		}

		return rm;
	}

	public List<RowMetaAndData> createData2() {
		List<RowMetaAndData> list = new ArrayList<RowMetaAndData>();

		RowMetaInterface rm = createRowMetaInterface2();

		Object[] r1 = new Object[] { new Long(1L) };
		Object[] r2 = new Object[] { new Long(2L) };
		Object[] r3 = new Object[] { new Long(3L) };
		Object[] r4 = new Object[] { new Long(4L) };
		Object[] r5 = new Object[] { new Long(5L) };
		Object[] r6 = new Object[] { new Long(6L) };
		Object[] r7 = new Object[] { new Long(7L) };
		Object[] r8 = new Object[] { new Long(8L) };
		Object[] r9 = new Object[] { new Long(9L) };

		list.add(new RowMetaAndData(rm, r1));
		list.add(new RowMetaAndData(rm, r2));
		list.add(new RowMetaAndData(rm, r3));
		list.add(new RowMetaAndData(rm, r4));
		list.add(new RowMetaAndData(rm, r5));
		list.add(new RowMetaAndData(rm, r6));
		list.add(new RowMetaAndData(rm, r7));
		list.add(new RowMetaAndData(rm, r8));
		list.add(new RowMetaAndData(rm, r9));

		return list;
	}

	/**
	 * Create result data for test case 2.
	 */
	public List<RowMetaAndData> createResultData2() {
		List<RowMetaAndData> list = new ArrayList<RowMetaAndData>();

		RowMetaInterface rm = createResultRowMetaInterface2();

		SimpleDateFormat sdf = null;
		try {
			sdf = new SimpleDateFormat("yyyyMMdd");
		} catch (IllegalArgumentException ex) {
			fail("Creating of result data failed in SimpleDateFormat: "
					+ ex.getMessage());
		}

		try {

			Object[] r1 = new Object[] { new Long(1L), sdf.parse("20070227") };
			Object[] r2 = new Object[] { new Long(2L), sdf.parse("20070228") };
			Object[] r3 = new Object[] { new Long(3L), sdf.parse("20070301") };
			Object[] r4 = new Object[] { new Long(4L), sdf.parse("20070302") };
			Object[] r5 = new Object[] { new Long(5L), sdf.parse("20070303") };
			Object[] r6 = new Object[] { new Long(6L), null };
			Object[] r7 = new Object[] { new Long(7L), null };
			Object[] r8 = new Object[] { new Long(8L), null };
			Object[] r9 = new Object[] { new Long(9L), null };

			list.add(new RowMetaAndData(rm, r1));
			list.add(new RowMetaAndData(rm, r2));
			list.add(new RowMetaAndData(rm, r3));
			list.add(new RowMetaAndData(rm, r4));
			list.add(new RowMetaAndData(rm, r5));
			list.add(new RowMetaAndData(rm, r6));
			list.add(new RowMetaAndData(rm, r7));
			list.add(new RowMetaAndData(rm, r8));
			list.add(new RowMetaAndData(rm, r9));

		} catch (ParseException ex) {
			fail("Creating of result data failed in object creation: "
					+ ex.getMessage());
		}

		return list;
	}

	public RowMetaInterface createRowMetaInterface3() {
		return createRowMetaInterface2();
	}

	public RowMetaInterface createResultRowMetaInterface3() {
		return createResultRowMetaInterface2();
	}

	public List<RowMetaAndData> createData3() {
		List<RowMetaAndData> list = new ArrayList<RowMetaAndData>();

		RowMetaInterface rm = createRowMetaInterface3();

		Object[] r1 = new Object[] { new Long(1L) };
		Object[] r2 = new Object[] { new Long(2L) };
		Object[] r3 = new Object[] { new Long(3L) };
		Object[] r4 = new Object[] { new Long(4L) };
		Object[] r5 = new Object[] { new Long(5L) };
		Object[] r6 = new Object[] { new Long(6L) };
		Object[] r7 = new Object[] { new Long(7L) };
		Object[] r8 = new Object[] { new Long(8L) };
		Object[] r9 = new Object[] { new Long(9L) };

		list.add(new RowMetaAndData(rm, r1));
		list.add(new RowMetaAndData(rm, r2));
		list.add(new RowMetaAndData(rm, r3));
		list.add(new RowMetaAndData(rm, r4));
		list.add(new RowMetaAndData(rm, r5));
		list.add(new RowMetaAndData(rm, r6));
		list.add(new RowMetaAndData(rm, r7));
		list.add(new RowMetaAndData(rm, r8));
		list.add(new RowMetaAndData(rm, r9));

		return list;
	}

	/**
	 * Create result data for test case 3.
	 */
	public List<RowMetaAndData> createResultData3() {
		List<RowMetaAndData> list = new ArrayList<RowMetaAndData>();

		RowMetaInterface rm = createResultRowMetaInterface3();

		SimpleDateFormat sdf = null;
		try {
			sdf = new SimpleDateFormat("yyyyMMdd");
		} catch (IllegalArgumentException ex) {
			fail("Creating of result data failed in SimpleDateFormat: "
					+ ex.getMessage());
		}

		try {

			Object[] r1 = new Object[] { new Long(1L), sdf.parse("20070227") };
			Object[] r2 = new Object[] { new Long(2L), sdf.parse("20070228") };
			Object[] r3 = new Object[] { new Long(3L), sdf.parse("20070301") };
			Object[] r4 = new Object[] { new Long(4L), sdf.parse("20070302") };
			Object[] r5 = new Object[] { new Long(5L), sdf.parse("20070303") };
			Object[] r6 = new Object[] { new Long(6L), sdf.parse("20070304") };
			Object[] r7 = new Object[] { new Long(7L), sdf.parse("20070305") };
			Object[] r8 = new Object[] { new Long(8L), sdf.parse("20070306") };
			Object[] r9 = new Object[] { new Long(9L), sdf.parse("20070307") };

			list.add(new RowMetaAndData(rm, r1));
			list.add(new RowMetaAndData(rm, r2));
			list.add(new RowMetaAndData(rm, r3));
			list.add(new RowMetaAndData(rm, r4));
			list.add(new RowMetaAndData(rm, r5));
			list.add(new RowMetaAndData(rm, r6));
			list.add(new RowMetaAndData(rm, r7));
			list.add(new RowMetaAndData(rm, r8));
			list.add(new RowMetaAndData(rm, r9));

		} catch (ParseException ex) {
			fail("Creating of result data failed in object creation: "
					+ ex.getMessage());
		}

		return list;
	}

	public RowMetaInterface createRowMetaInterface4() {
		return createRowMetaInterface2();
	}

	public RowMetaInterface createResultRowMetaInterface4() {
		return createResultRowMetaInterface2();
	}

	public List<RowMetaAndData> createData4() {
		List<RowMetaAndData> list = new ArrayList<RowMetaAndData>();

		RowMetaInterface rm = createRowMetaInterface4();

		Object[] r1 = new Object[] { new Long(1L) };
		Object[] r2 = new Object[] { new Long(2L) };
		Object[] r3 = new Object[] { new Long(3L) };
		Object[] r4 = new Object[] { new Long(4L) };
		Object[] r5 = new Object[] { new Long(5L) };
		Object[] r6 = new Object[] { new Long(6L) };
		Object[] r7 = new Object[] { new Long(7L) };
		Object[] r8 = new Object[] { new Long(8L) };
		Object[] r9 = new Object[] { new Long(9L) };

		list.add(new RowMetaAndData(rm, r1));
		list.add(new RowMetaAndData(rm, r2));
		list.add(new RowMetaAndData(rm, r3));
		list.add(new RowMetaAndData(rm, r4));
		list.add(new RowMetaAndData(rm, r5));
		list.add(new RowMetaAndData(rm, r6));
		list.add(new RowMetaAndData(rm, r7));
		list.add(new RowMetaAndData(rm, r8));
		list.add(new RowMetaAndData(rm, r9));

		return list;
	}

	/**
	 * Create result data for test case 4.
	 */
	public List<RowMetaAndData> createResultData4() {
		List<RowMetaAndData> list = new ArrayList<RowMetaAndData>();

		RowMetaInterface rm = createResultRowMetaInterface4();

		SimpleDateFormat sdf = null;
		try {
			sdf = new SimpleDateFormat("yyyyMMdd");
		} catch (IllegalArgumentException ex) {
			fail("Creating of result data failed in SimpleDateFormat: "
					+ ex.getMessage());
		}

		try {

			Object[] r1 = new Object[] { new Long(1L), sdf.parse("20070227") };
			Object[] r2 = new Object[] { new Long(2L), sdf.parse("20070228") };
			Object[] r3 = new Object[] { new Long(3L), sdf.parse("20070301") };
			Object[] r4 = new Object[] { new Long(4L), sdf.parse("20070302") };
			Object[] r5 = new Object[] { new Long(5L), sdf.parse("20070303") };

			list.add(new RowMetaAndData(rm, r1));
			list.add(new RowMetaAndData(rm, r2));
			list.add(new RowMetaAndData(rm, r3));
			list.add(new RowMetaAndData(rm, r4));
			list.add(new RowMetaAndData(rm, r5));

		} catch (ParseException ex) {
			fail("Creating of result data failed in object creation: "
					+ ex.getMessage());
		}

		return list;
	}

	public RowMetaInterface createResultRowMetaInterface5() {
		return createResultRowMetaInterface1();
	}

	/**
	 * Create result data for test case 5.
	 */
	public List<RowMetaAndData> createResultData5() {
		List<RowMetaAndData> list = new ArrayList<RowMetaAndData>();

		RowMetaInterface rm = createResultRowMetaInterface5();

		SimpleDateFormat sdf = null;
		try {
			sdf = new SimpleDateFormat("yyyyMMdd");
		} catch (IllegalArgumentException ex) {
			fail("Creating of result data failed in SimpleDateFormat: "
					+ ex.getMessage());
		}

		try {

			Object[] r1 = new Object[] { sdf.parse("20070227") };
			Object[] r2 = new Object[] { sdf.parse("20070228") };
			Object[] r3 = new Object[] { sdf.parse("20070301") };
			Object[] r4 = new Object[] { sdf.parse("20070302") };

			list.add(new RowMetaAndData(rm, r1));
			list.add(new RowMetaAndData(rm, r2));
			list.add(new RowMetaAndData(rm, r3));
			list.add(new RowMetaAndData(rm, r4));

		} catch (ParseException ex) {
			fail("Creating of result data failed in object creation: "
					+ ex.getMessage());
		}

		return list;
	}

	/**
	 * Check the 2 lists comparing the rows in order. If they are not the same
	 * fail the test.
	 */
	public void checkRows(List<RowMetaAndData> rows1, List<RowMetaAndData> rows2) {
		int idx = 1;
		if (rows1.size() != rows2.size()) {
			fail("Number of rows is not the same: " + rows1.size() + " and "
					+ rows2.size());
		}
		Iterator<RowMetaAndData> it1 = rows1.iterator();
		Iterator<RowMetaAndData> it2 = rows2.iterator();

		while (it1.hasNext() && it2.hasNext()) {
			RowMetaAndData rm1 = it1.next();
			RowMetaAndData rm2 = it2.next();

			Object[] r1 = rm1.getData();
			Object[] r2 = rm2.getData();

			if (rm1.size() != rm2.size()) {
				fail("row nr " + idx + " is not equal");
			}
			int fields[] = new int[r1.length];
			for (int ydx = 0; ydx < r1.length; ydx++) {
				fields[ydx] = ydx;
			}
			try {
				if (rm1.getRowMeta().compare(r1, r2, fields) != 0) {
					fail("row nr " + idx + " is not equal");
				}
			} catch (KettleValueException e) {
				fail("row nr " + idx + " is not equal");
			}

			idx++;
		}
	}

	/**
	 * Test case for Date Generator step. Injector step to a Date generator.
	 * Less rows coming in than defined in the begin to end range.
	 */
	public void testDateGenerator1() throws Exception {
		EnvUtil.environmentInit();

		//
		// Create a new transformation...
		//
		TransMeta transMeta = new TransMeta();
		transMeta.setName("DateGen1");

		StepLoader steploader = StepLoader.getInstance();

		// 
		// create an injector step...
		//
		String injectorStepname = "injector step";
		InjectorMeta im = new InjectorMeta();

		// Set the information of the injector.
		String injectorPid = steploader.getStepPluginID(im);
		StepMeta injectorStep = new StepMeta(injectorPid, injectorStepname,
				(StepMetaInterface) im);
		transMeta.addStep(injectorStep);

		// 
		// Create an Date Generator step
		//
		String dateGenName = "date generator step";
		DateGeneratorMeta dg = new DateGeneratorMeta();
		dg.setFieldName("date");
		dg.setDateFormat("yyyyMMdd");
		dg.setBeginDate("20071225");
		dg.setEndDate("20080105");
		dg.setDiscardRowsAfterEnd(false);

		String DateGenPid = steploader.getStepPluginID(dg);
		StepMeta DateGenStep = new StepMeta(DateGenPid, dateGenName,
				(StepMetaInterface) dg);
		transMeta.addStep(DateGenStep);

		TransHopMeta hop = new TransHopMeta(injectorStep, DateGenStep);
		transMeta.addTransHop(hop);

		// 
		// Create a dummy step
		//
		String dummyStepname = "dummy step";
		DummyTransMeta dm = new DummyTransMeta();

		String dummyPid = steploader.getStepPluginID(dm);
		StepMeta dummyStep = new StepMeta(dummyPid, dummyStepname,
				(StepMetaInterface) dm);
		transMeta.addStep(dummyStep);

		TransHopMeta hi3 = new TransHopMeta(DateGenStep, dummyStep);
		transMeta.addTransHop(hi3);

		// Now execute the transformation...
		Trans trans = new Trans(transMeta);

		trans.prepareExecution(null);

		StepInterface si = trans.getStepInterface(dateGenName, 0);
		RowStepCollector dateGenRc = new RowStepCollector();
		si.addRowListener(dateGenRc);

		si = trans.getStepInterface(dummyStepname, 0);
		RowStepCollector dummyRc = new RowStepCollector();
		si.addRowListener(dummyRc);

		RowProducer rp = trans.addRowProducer(injectorStepname, 0);
		trans.startThreads();

		// add rows
		List<RowMetaAndData> inputList = createData1();
		Iterator<RowMetaAndData> it = inputList.iterator();
		while (it.hasNext()) {
			RowMetaAndData rm = it.next();
			rp.putRow(rm.getRowMeta(), rm.getData());
		}
		rp.finished();

		trans.waitUntilFinished();

		// Compare the results
		List<RowMetaAndData> resultRows = dummyRc.getRowsWritten();
		List<RowMetaAndData> goldenImageRows = createResultData1();

		checkRows(goldenImageRows, resultRows);
	}

	/**
	 * Test case for Date Generator step. Injector step to a Date generator.
	 * More rows coming in than defined in the begin to end range. Also already
	 * 1 field in the input (so that one needs to be retained).
	 */
	public void testDateGenerator2() throws Exception {
		EnvUtil.environmentInit();

		//
		// Create a new transformation...
		//
		TransMeta transMeta = new TransMeta();
		transMeta.setName("DateGen2");

		StepLoader steploader = StepLoader.getInstance();

		// 
		// create an injector step...
		//
		String injectorStepname = "injector step";
		InjectorMeta im = new InjectorMeta();

		// Set the information of the injector.
		String injectorPid = steploader.getStepPluginID(im);
		StepMeta injectorStep = new StepMeta(injectorPid, injectorStepname,
				(StepMetaInterface) im);
		transMeta.addStep(injectorStep);

		// 
		// Create an Date Generator step
		//
		String dateGenName = "date generator step";
		DateGeneratorMeta dg = new DateGeneratorMeta();
		dg.setFieldName("date");
		dg.setDateFormat("yyyyMMdd");
		dg.setBeginDate("20070227");
		dg.setEndDate("20070304");
		dg.setDiscardRowsAfterEnd(false);

		String DateGenPid = steploader.getStepPluginID(dg);
		StepMeta DateGenStep = new StepMeta(DateGenPid, dateGenName,
				(StepMetaInterface) dg);
		transMeta.addStep(DateGenStep);

		TransHopMeta hop = new TransHopMeta(injectorStep, DateGenStep);
		transMeta.addTransHop(hop);

		// 
		// Create a dummy step
		//
		String dummyStepname = "dummy step";
		DummyTransMeta dm = new DummyTransMeta();

		String dummyPid = steploader.getStepPluginID(dm);
		StepMeta dummyStep = new StepMeta(dummyPid, dummyStepname,
				(StepMetaInterface) dm);
		transMeta.addStep(dummyStep);

		TransHopMeta hi3 = new TransHopMeta(DateGenStep, dummyStep);
		transMeta.addTransHop(hi3);

		// Now execute the transformation...
		Trans trans = new Trans(transMeta);

		trans.prepareExecution(null);

		StepInterface si = trans.getStepInterface(dateGenName, 0);
		RowStepCollector dateGenRc = new RowStepCollector();
		si.addRowListener(dateGenRc);

		si = trans.getStepInterface(dummyStepname, 0);
		RowStepCollector dummyRc = new RowStepCollector();
		si.addRowListener(dummyRc);

		RowProducer rp = trans.addRowProducer(injectorStepname, 0);
		trans.startThreads();

		// add rows
		List<RowMetaAndData> inputList = createData2();
		Iterator<RowMetaAndData> it = inputList.iterator();
		while (it.hasNext()) {
			RowMetaAndData rm = it.next();
			rp.putRow(rm.getRowMeta(), rm.getData());
		}
		rp.finished();

		trans.waitUntilFinished();

		// Compare the results
		List<RowMetaAndData> resultRows = dummyRc.getRowsWritten();
		List<RowMetaAndData> goldenImageRows = createResultData2();

		checkRows(goldenImageRows, resultRows);
	}

	/**
	 * Test case for Date Generator step. Injector step to a Date generator. End
	 * date not filled in. Also already 1 field in the input (so that one needs
	 * to be retained).
	 */
	public void testDateGenerator3() throws Exception {
		EnvUtil.environmentInit();

		//
		// Create a new transformation...
		//
		TransMeta transMeta = new TransMeta();
		transMeta.setName("DateGen3");

		StepLoader steploader = StepLoader.getInstance();

		// 
		// create an injector step...
		//
		String injectorStepname = "injector step";
		InjectorMeta im = new InjectorMeta();

		// Set the information of the injector.
		String injectorPid = steploader.getStepPluginID(im);
		StepMeta injectorStep = new StepMeta(injectorPid, injectorStepname,
				(StepMetaInterface) im);
		transMeta.addStep(injectorStep);

		// 
		// Create an Date Generator step
		//
		String dateGenName = "date generator step";
		DateGeneratorMeta dg = new DateGeneratorMeta();
		dg.setFieldName("date");
		dg.setDateFormat("MMyyyydd"); // change the mask for a change.
		dg.setBeginDate("02200727");
		dg.setEndDate(null);
		dg.setDiscardRowsAfterEnd(false);

		String DateGenPid = steploader.getStepPluginID(dg);
		StepMeta DateGenStep = new StepMeta(DateGenPid, dateGenName,
				(StepMetaInterface) dg);
		transMeta.addStep(DateGenStep);

		TransHopMeta hop = new TransHopMeta(injectorStep, DateGenStep);
		transMeta.addTransHop(hop);

		// 
		// Create a dummy step
		//
		String dummyStepname = "dummy step";
		DummyTransMeta dm = new DummyTransMeta();

		String dummyPid = steploader.getStepPluginID(dm);
		StepMeta dummyStep = new StepMeta(dummyPid, dummyStepname,
				(StepMetaInterface) dm);
		transMeta.addStep(dummyStep);

		TransHopMeta hi3 = new TransHopMeta(DateGenStep, dummyStep);
		transMeta.addTransHop(hi3);

		// Now execute the transformation...
		Trans trans = new Trans(transMeta);

		trans.prepareExecution(null);

		StepInterface si = trans.getStepInterface(dateGenName, 0);
		RowStepCollector dateGenRc = new RowStepCollector();
		si.addRowListener(dateGenRc);

		si = trans.getStepInterface(dummyStepname, 0);
		RowStepCollector dummyRc = new RowStepCollector();
		si.addRowListener(dummyRc);

		RowProducer rp = trans.addRowProducer(injectorStepname, 0);
		trans.startThreads();

		// add rows
		List<RowMetaAndData> inputList = createData3();
		Iterator<RowMetaAndData> it = inputList.iterator();
		while (it.hasNext()) {
			RowMetaAndData rm = it.next();
			rp.putRow(rm.getRowMeta(), rm.getData());
		}
		rp.finished();

		trans.waitUntilFinished();

		// Compare the results
		List<RowMetaAndData> resultRows = dummyRc.getRowsWritten();
		List<RowMetaAndData> goldenImageRows = createResultData3();

		checkRows(goldenImageRows, resultRows);
	}

	/**
	 * Test case for Date Generator step. Injector step to a Date generator. End
	 * date filled in and discard rows active. Also already 1 field in the input
	 * (so that one needs to be retained).
	 */
	public void testDateGenerator4() throws Exception {
		EnvUtil.environmentInit();

		//
		// Create a new transformation...
		//
		TransMeta transMeta = new TransMeta();
		transMeta.setName("DateGen4");

		StepLoader steploader = StepLoader.getInstance();

		// 
		// create an injector step...
		//
		String injectorStepname = "injector step";
		InjectorMeta im = new InjectorMeta();

		// Set the information of the injector.
		String injectorPid = steploader.getStepPluginID(im);
		StepMeta injectorStep = new StepMeta(injectorPid, injectorStepname,
				(StepMetaInterface) im);
		transMeta.addStep(injectorStep);

		// 
		// Create an Date Generator step
		//
		String dateGenName = "date generator step";
		DateGeneratorMeta dg = new DateGeneratorMeta();
		dg.setFieldName("date");
		dg.setDateFormat("MMyyyydd"); // change the mask for a change.
		dg.setBeginDate("02200727");
		dg.setEndDate("03200704");
		dg.setDiscardRowsAfterEnd(true);

		String DateGenPid = steploader.getStepPluginID(dg);
		StepMeta DateGenStep = new StepMeta(DateGenPid, dateGenName,
				(StepMetaInterface) dg);
		transMeta.addStep(DateGenStep);

		TransHopMeta hop = new TransHopMeta(injectorStep, DateGenStep);
		transMeta.addTransHop(hop);

		// 
		// Create a dummy step
		//
		String dummyStepname = "dummy step";
		DummyTransMeta dm = new DummyTransMeta();

		String dummyPid = steploader.getStepPluginID(dm);
		StepMeta dummyStep = new StepMeta(dummyPid, dummyStepname,
				(StepMetaInterface) dm);
		transMeta.addStep(dummyStep);

		TransHopMeta hi3 = new TransHopMeta(DateGenStep, dummyStep);
		transMeta.addTransHop(hi3);

		// Now execute the transformation...
		Trans trans = new Trans(transMeta);

		trans.prepareExecution(null);

		StepInterface si = trans.getStepInterface(dateGenName, 0);
		RowStepCollector dateGenRc = new RowStepCollector();
		si.addRowListener(dateGenRc);

		si = trans.getStepInterface(dummyStepname, 0);
		RowStepCollector dummyRc = new RowStepCollector();
		si.addRowListener(dummyRc);

		RowProducer rp = trans.addRowProducer(injectorStepname, 0);
		trans.startThreads();

		// add rows
		List<RowMetaAndData> inputList = createData4();
		Iterator<RowMetaAndData> it = inputList.iterator();
		while (it.hasNext()) {
			RowMetaAndData rm = it.next();
			rp.putRow(rm.getRowMeta(), rm.getData());
		}
		rp.finished();

		trans.waitUntilFinished();

		// Compare the results
		List<RowMetaAndData> resultRows = dummyRc.getRowsWritten();
		List<RowMetaAndData> goldenImageRows = createResultData4();

		checkRows(goldenImageRows, resultRows);
	}

	/**
	 * Test case for Date Generator step. Date generator to dummy. The generator
	 * doesn't need input.
	 */
	public void testDateGenerator5() throws Exception {
		EnvUtil.environmentInit();

		//
		// Create a new transformation...
		//
		TransMeta transMeta = new TransMeta();
		transMeta.setName("DateGen5");

		StepLoader steploader = StepLoader.getInstance();

		// 
		// Create an Date Generator step
		//
		String dateGenName = "date generator step";
		DateGeneratorMeta dg = new DateGeneratorMeta();
		dg.setFieldName("date");
		dg.setDateFormat("MM-dd-yyyy"); // change the mask for a change.
		dg.setBeginDate("02-27-2007");
		dg.setEndDate("03-03-2007");
		dg.setDiscardRowsAfterEnd(false);

		String DateGenPid = steploader.getStepPluginID(dg);
		StepMeta DateGenStep = new StepMeta(DateGenPid, dateGenName,
				(StepMetaInterface) dg);
		transMeta.addStep(DateGenStep);

		// 
		// Create a dummy step
		//
		String dummyStepname = "dummy step";
		DummyTransMeta dm = new DummyTransMeta();

		String dummyPid = steploader.getStepPluginID(dm);
		StepMeta dummyStep = new StepMeta(dummyPid, dummyStepname,
				(StepMetaInterface) dm);
		transMeta.addStep(dummyStep);

		TransHopMeta hi3 = new TransHopMeta(DateGenStep, dummyStep);
		transMeta.addTransHop(hi3);

		// Now execute the transformation...
		Trans trans = new Trans(transMeta);

		trans.prepareExecution(null);

		StepInterface si = trans.getStepInterface(dateGenName, 0);
		RowStepCollector dateGenRc = new RowStepCollector();
		si.addRowListener(dateGenRc);

		si = trans.getStepInterface(dummyStepname, 0);
		RowStepCollector dummyRc = new RowStepCollector();
		si.addRowListener(dummyRc);

		// We don't need input, as the row generator can work without input.
		trans.startThreads();
		trans.waitUntilFinished();

		// Compare the results
		List<RowMetaAndData> resultRows = dummyRc.getRowsWritten();
		List<RowMetaAndData> goldenImageRows = createResultData5();

		checkRows(goldenImageRows, resultRows);
	}
}