/*************************************************************************************** 
 * Copyright (C) 2007 Sven Boden (svenboden@illunus.com).  All rights reserved. 
 * This software was developed by Sven Boden and is provided under the terms 
 * of the GNU Lesser General Public License, Version 2.1. You may not use 
 * this file except in compliance with the license. A copy of the license, 
 * is included with the binaries and source code. The Original Code is Sven Boden.  
 * The Initial Developer is Sven Boden.
 *
 * Software distributed under the GNU Lesser Public License is distributed on an 
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. 
 * Please refer to the license for the specific language governing your rights 
 * and limitations.
 ***************************************************************************************/

package com.illunus.di.ui.trans.steps.dategenerator;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.ShellAdapter;
import org.eclipse.swt.events.ShellEvent;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.pentaho.di.core.Const;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.pentaho.di.trans.TransPreviewFactory;
import org.pentaho.di.trans.step.BaseStepMeta;
import org.pentaho.di.trans.step.StepDialogInterface;
import org.pentaho.di.ui.core.dialog.EnterNumberDialog;
import org.pentaho.di.ui.core.dialog.EnterTextDialog;
import org.pentaho.di.ui.core.dialog.ErrorDialog;
import org.pentaho.di.ui.core.dialog.PreviewRowsDialog;
import org.pentaho.di.ui.core.widget.TextVar;
import org.pentaho.di.ui.trans.dialog.TransPreviewProgressDialog;
import org.pentaho.di.ui.trans.step.BaseStepDialog;

import com.illunus.di.trans.steps.dategenerator.DateGeneratorMeta;
import com.illunus.di.trans.steps.dategenerator.Messages;

public class DateGeneratorDialog extends BaseStepDialog implements
		StepDialogInterface {

	private Label wlFieldName;

	private Text wFieldName;

	private FormData fdlFieldName, fdFieldName;

	private Label wlDateFormat;

	private TextVar wDateFormat;

	private FormData fdlDateFormat, fdDateFormat;

	private Label wlBeginDate;

	private TextVar wBeginDate;

	private FormData fdlBeginDate, fdBeginDate;

	private Label wlEndDate;

	private TextVar wEndDate;

	private FormData fdlEndDate, fdEndDate;

	private Label wlDiscardRows;

	private Button wDiscardRows;

	private FormData fdlDiscardRows, fdDiscardRows;

	private DateGeneratorMeta input;

	public DateGeneratorDialog(Shell parent, Object in, TransMeta transMeta,
			String sname) {
		super(parent, (BaseStepMeta) in, transMeta, sname);
		input = (DateGeneratorMeta) in;
	}

	public String open() {
		Shell parent = getParent();
		Display display = parent.getDisplay();

		shell = new Shell(parent, SWT.DIALOG_TRIM | SWT.RESIZE | SWT.MAX
				| SWT.MIN);
		props.setLook(shell);
		setShellImage(shell, input);

		ModifyListener lsMod = new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				input.setChanged();
			}
		};
		changed = input.hasChanged();

		FormLayout formLayout = new FormLayout();
		formLayout.marginWidth = Const.FORM_MARGIN;
		formLayout.marginHeight = Const.FORM_MARGIN;

		shell.setLayout(formLayout);
		shell.setText(Messages.getString("DateGeneratorDialog.DialogTitle"));

		int middle = props.getMiddlePct();
		int margin = Const.MARGIN;

		// Stepname line
		wlStepname = new Label(shell, SWT.RIGHT);
		wlStepname.setText(Messages.getString("System.Label.StepName"));
		props.setLook(wlStepname);
		fdlStepname = new FormData();
		fdlStepname.left = new FormAttachment(0, 0);
		fdlStepname.right = new FormAttachment(middle, -margin);
		fdlStepname.top = new FormAttachment(0, margin);
		wlStepname.setLayoutData(fdlStepname);
		wStepname = new Text(shell, SWT.SINGLE | SWT.LEFT | SWT.BORDER);
		wStepname.setText(stepname);
		props.setLook(wStepname);
		wStepname.addModifyListener(lsMod);
		fdStepname = new FormData();
		fdStepname.left = new FormAttachment(middle, 0);
		fdStepname.top = new FormAttachment(0, margin);
		fdStepname.right = new FormAttachment(100, 0);
		wStepname.setLayoutData(fdStepname);

		// The field name to put the date in
		wlFieldName = new Label(shell, SWT.RIGHT);
		wlFieldName.setText(Messages
				.getString("DateGeneratorDialog.FieldName.Label"));
		props.setLook(wlFieldName);
		fdlFieldName = new FormData();
		fdlFieldName.left = new FormAttachment(0, 0);
		fdlFieldName.right = new FormAttachment(middle, -margin);
		fdlFieldName.top = new FormAttachment(wStepname, margin);
		wlFieldName.setLayoutData(fdlFieldName);
		wFieldName = new Text(shell, SWT.SINGLE | SWT.LEFT | SWT.BORDER);
		props.setLook(wFieldName);
		wFieldName.addModifyListener(lsMod);
		fdFieldName = new FormData();
		fdFieldName.left = new FormAttachment(middle, 0);
		fdFieldName.top = new FormAttachment(wStepname, margin);
		fdFieldName.right = new FormAttachment(100, 0);
		wFieldName.setLayoutData(fdFieldName);

		// The date format for begin and end date
		wlDateFormat = new Label(shell, SWT.RIGHT);
		wlDateFormat.setText(Messages
				.getString("DateGeneratorDialog.DateFormat.Label"));
		props.setLook(wlDateFormat);
		fdlDateFormat = new FormData();
		fdlDateFormat.left = new FormAttachment(0, 0);
		fdlDateFormat.right = new FormAttachment(middle, -margin);
		fdlDateFormat.top = new FormAttachment(wFieldName, margin);
		wlDateFormat.setLayoutData(fdlDateFormat);
		wDateFormat = new TextVar(transMeta, shell, SWT.SINGLE | SWT.LEFT
				| SWT.BORDER);
		props.setLook(wDateFormat);
		wDateFormat.addModifyListener(lsMod);
		fdDateFormat = new FormData();
		fdDateFormat.left = new FormAttachment(middle, 0);
		fdDateFormat.top = new FormAttachment(wFieldName, margin);
		fdDateFormat.right = new FormAttachment(100, 0);
		wDateFormat.setLayoutData(fdDateFormat);

		// The begin date
		wlBeginDate = new Label(shell, SWT.RIGHT);
		wlBeginDate.setText(Messages
				.getString("DateGeneratorDialog.BeginDate.Label"));
		props.setLook(wlBeginDate);
		fdlBeginDate = new FormData();
		fdlBeginDate.left = new FormAttachment(0, 0);
		fdlBeginDate.right = new FormAttachment(middle, -margin);
		fdlBeginDate.top = new FormAttachment(wDateFormat, margin);
		wlBeginDate.setLayoutData(fdlBeginDate);
		wBeginDate = new TextVar(transMeta, shell, SWT.SINGLE | SWT.LEFT
				| SWT.BORDER);
		props.setLook(wBeginDate);
		wBeginDate.addModifyListener(lsMod);
		fdBeginDate = new FormData();
		fdBeginDate.left = new FormAttachment(middle, 0);
		fdBeginDate.top = new FormAttachment(wDateFormat, margin);
		fdBeginDate.right = new FormAttachment(100, 0);
		wBeginDate.setLayoutData(fdBeginDate);

		// The end date
		wlEndDate = new Label(shell, SWT.RIGHT);
		wlEndDate.setText(Messages
				.getString("DateGeneratorDialog.EndDate.Label"));
		props.setLook(wlEndDate);
		fdlEndDate = new FormData();
		fdlEndDate.left = new FormAttachment(0, 0);
		fdlEndDate.right = new FormAttachment(middle, -margin);
		fdlEndDate.top = new FormAttachment(wBeginDate, margin);
		wlEndDate.setLayoutData(fdlEndDate);
		wEndDate = new TextVar(transMeta, shell, SWT.SINGLE | SWT.LEFT
				| SWT.BORDER);
		props.setLook(wEndDate);
		wEndDate.addModifyListener(lsMod);
		fdEndDate = new FormData();
		fdEndDate.left = new FormAttachment(middle, 0);
		fdEndDate.top = new FormAttachment(wBeginDate, margin);
		fdEndDate.right = new FormAttachment(100, 0);
		wEndDate.setLayoutData(fdEndDate);

		// UpdateBypassed line
		wlDiscardRows = new Label(shell, SWT.RIGHT);
		wlDiscardRows.setText(Messages
				.getString("DateGeneratorDialog.DiscardRows.Label")); //$NON-NLS-1$
		props.setLook(wlDiscardRows);
		fdlDiscardRows = new FormData();
		fdlDiscardRows.left = new FormAttachment(0, 0);
		fdlDiscardRows.top = new FormAttachment(wEndDate, margin);
		fdlDiscardRows.right = new FormAttachment(middle, -margin);
		wlDiscardRows.setLayoutData(fdlDiscardRows);
		wDiscardRows = new Button(shell, SWT.CHECK);
		props.setLook(wDiscardRows);
		fdDiscardRows = new FormData();
		fdDiscardRows.left = new FormAttachment(middle, 0);
		fdDiscardRows.top = new FormAttachment(wEndDate, margin);
		fdDiscardRows.right = new FormAttachment(100, 0);
		wDiscardRows.setLayoutData(fdDiscardRows);
		wDiscardRows.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent arg0) {
				input.setChanged();
			}
		});

		wOK = new Button(shell, SWT.PUSH);
		wOK.setText(Messages.getString("System.Button.OK"));
		wPreview = new Button(shell, SWT.PUSH);
		wPreview.setText(Messages.getString("System.Button.Preview"));
		wCancel = new Button(shell, SWT.PUSH);
		wCancel.setText(Messages.getString("System.Button.Cancel"));

		setButtonPositions(new Button[] { wOK, wCancel, wPreview }, margin,
				wDiscardRows);

		// Add listeners
		lsOK = new Listener() {
			public void handleEvent(Event e) {
				ok();
			}
		};
		lsPreview = new Listener() {
			public void handleEvent(Event e) {
				preview();
			}
		};
		lsCancel = new Listener() {
			public void handleEvent(Event e) {
				cancel();
			}
		};

		wOK.addListener(SWT.Selection, lsOK);
		wPreview.addListener(SWT.Selection, lsPreview);
		wCancel.addListener(SWT.Selection, lsCancel);

		lsDef = new SelectionAdapter() {
			public void widgetDefaultSelected(SelectionEvent e) {
				ok();
			}
		};

		wStepname.addSelectionListener(lsDef);
		wFieldName.addSelectionListener(lsDef);

		// Detect X or ALT-F4 or something that kills this window...
		shell.addShellListener(new ShellAdapter() {
			public void shellClosed(ShellEvent e) {
				cancel();
			}
		});

		// Set the shell size, based upon previous time...
		setSize();

		getData();
		input.setChanged(changed);

		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		return stepname;
	}

	/**
	 * Copy information from the meta-data input to the dialog fields.
	 */
	public void getData() {
		if (log.isDebug())
			log.logDebug(toString(), "getting fields info...");

		if (input.getFieldName() != null)
			wFieldName.setText(input.getFieldName());

		if (input.getDateFormat() != null)
			wDateFormat.setText(input.getDateFormat());

		if (input.getBeginDate() != null)
			wBeginDate.setText(input.getBeginDate());

		if (input.getEndDate() != null)
			wEndDate.setText(input.getEndDate());

		wDiscardRows.setSelection(input.isDiscardRowsAfterEnd());

		wStepname.selectAll();
	}

	private void cancel() {
		stepname = null;
		input.setChanged(changed);
		dispose();
	}

	private void ok() {
		if (Const.isEmpty(wStepname.getText()))
			return;

		stepname = wStepname.getText(); // return value
		try {
			getInfo(new DateGeneratorMeta()); // to see if there is an
												// exception

			getInfo(input); // to put the content on the input structure for
			// real if all is well.
			dispose();
		} catch (KettleException e) {
			new ErrorDialog(
					shell,
					Messages
							.getString("DateGeneratorDialog.Illegal.Dialog.Settings.Title"),
					Messages
							.getString("DateGeneratorDialog.Illegal.Dialog.Settings.Message"),
					e);
		}
	}

	private void getInfo(DateGeneratorMeta meta) throws KettleException {

		meta.setFieldName(wFieldName.getText());
		meta.setDateFormat(wDateFormat.getText());
		meta.setBeginDate(wBeginDate.getText());
		meta.setEndDate(wEndDate.getText());
		meta.setDiscardRowsAfterEnd(wDiscardRows.getSelection());
	}

	public String toString() {
		return this.getClass().getName();
	}

	/**
	 * Preview the data generated by this step. This generates a transformation
	 * using this step & a dummy and previews it.
	 */
	private void preview() {
		DateGeneratorMeta oneMeta = new DateGeneratorMeta();
		try {
			getInfo(oneMeta);
		} catch (KettleException e) {
			new ErrorDialog(
					shell,
					Messages
							.getString("DateGeneratorDialog.Illegal.Dialog.Settings.Title"),
					Messages
							.getString("DateGeneratorDialog.Illegal.Dialog.Settings.Message"),
					e);
			return;
		}

		TransMeta previewMeta = TransPreviewFactory
				.generatePreviewTransformation(transMeta, oneMeta, wStepname
						.getText());

		EnterNumberDialog numberDialog = new EnterNumberDialog(shell, props
				.getDefaultPreviewSize(), Messages
				.getString("System.Dialog.EnterPreviewSize.Title"), Messages
				.getString("System.Dialog.EnterPreviewSize.Message"));
		int previewSize = numberDialog.open();
		if (previewSize > 0) {
			TransPreviewProgressDialog progressDialog = new TransPreviewProgressDialog(
					shell, previewMeta, new String[] { wStepname.getText() },
					new int[] { previewSize });
			progressDialog.open();

			Trans trans = progressDialog.getTrans();
			String loggingText = progressDialog.getLoggingText();

			if (!progressDialog.isCancelled()) {
				if (trans.getResult() != null
						&& trans.getResult().getNrErrors() > 0) {
					EnterTextDialog etd = new EnterTextDialog(
							shell,
							Messages
									.getString("System.Dialog.PreviewError.Title"),
							Messages
									.getString("System.Dialog.PreviewError.Message"),
							loggingText, true);
					etd.setReadOnly();
					etd.open();
				}
			}

			PreviewRowsDialog prd = new PreviewRowsDialog(shell, transMeta,
					SWT.NONE, wStepname.getText(), progressDialog
							.getPreviewRowsMeta(wStepname.getText()),
					progressDialog.getPreviewRows(wStepname.getText()),
					loggingText);
			prd.open();
		}
	}
}