
Thank you for using our software. This package is an extension/plug-in for Pentaho 3.1. This
step is licensed under LGPL 2.1 (license is included for reference).

The Date Generator step will generate date sequences.

To get started, look in the [docs] directory for the files [Illunus - Plugin Installation.pdf] and
[Illunus - Date Generator Step]. In it, you'll find an installation description and a user manual for the 
Date Generator step.

Basically, what installation comes down to:

1) Have a working PDI 3.1
2) Copy the jar files from the lib directory of this distribution to the libext directory PDI
3) Add com.illunus to the environment variable KETTLE_PLUGIN_PACKAGES
4) Start PDI

We really hope you will find Pentaho Data Integration useful in your daily work.

Contact us for more information : 

  Mail: support@illunus.com

  Website: http://www.sourceforge.net look for Illunus

